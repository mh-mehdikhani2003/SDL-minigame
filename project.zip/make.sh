g++ main.cpp -lSDL2 -lSDL2main -lSDL2_ttf -lSDL2_gfx -lSDL2_image -o Program.out
